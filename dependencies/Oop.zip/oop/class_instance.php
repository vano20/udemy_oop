<?php 


class Cars {



function gretting(){

	echo "Hello Student";


	}


}

$bmw = new Cars();

$mercedes = new Cars();



$bmw->gretting();








 ?>
